plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "uk.co.maintenancestock"
    compileSdk = 35
    defaultConfig {
        applicationId = "uk.co.maintenancestock"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

package uk.co.maintenancestock

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class StockItem(
    var id: String, var name: String, var category: String, var qty: Double,
    var unit: String, var min: Double, var cost: Double, var location: String,
    var supplier: String, var notes: String
)
data class Movement(val date: String, val item: String, val type: String, val qty: Double, val unit: String, val job: String, val balance: Double)

class MainActivity : Activity() {
    private val green = Color.rgb(36,54,46)
    private val pale = Color.rgb(238,243,238)
    private val cats = listOf("Fixings","Plumbing","Electrical","Consumables","Decorating","Building materials","Tools","PPE & safety","Cleaning","Replacement parts","Other")
    private val units = listOf("pcs","boxes","packs","rolls","tubes","litres","metres","lengths","bags","sheets","sets","pairs","bottles","kits")
    private val locations = listOf("Van","Workshop","Storeroom","Site","Other")
    private val stock = mutableListOf<StockItem>()
    private val history = mutableListOf<Movement>()
    private var page = "Stock"
    private var searchText = ""
    private var lowOnly = false
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = green
        loadData()
        showPage()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun saveData() {
        val s = JSONArray()
        stock.forEach { x -> s.put(JSONObject().put("id",x.id).put("name",x.name).put("category",x.category).put("qty",x.qty).put("unit",x.unit).put("min",x.min).put("cost",x.cost).put("location",x.location).put("supplier",x.supplier).put("notes",x.notes)) }
        val h = JSONArray()
        history.forEach { x -> h.put(JSONObject().put("date",x.date).put("item",x.item).put("type",x.type).put("qty",x.qty).put("unit",x.unit).put("job",x.job).put("balance",x.balance)) }
        getSharedPreferences("inventory", MODE_PRIVATE).edit().putString("stock",s.toString()).putString("history",h.toString()).apply()
    }
    private fun loadData() {
        val p = getSharedPreferences("inventory", MODE_PRIVATE)
        try {
            val a = JSONArray(p.getString("stock","[]"))
            for(i in 0 until a.length()) { val o=a.getJSONObject(i); stock.add(StockItem(o.optString("id"),o.optString("name"),o.optString("category","Other"),o.optDouble("qty"),o.optString("unit","pcs"),o.optDouble("min"),o.optDouble("cost"),o.optString("location","Van"),o.optString("supplier"),o.optString("notes"))) }
            val b = JSONArray(p.getString("history","[]"))
            for(i in 0 until b.length()) { val o=b.getJSONObject(i); history.add(Movement(o.optString("date"),o.optString("item"),o.optString("type"),o.optDouble("qty"),o.optString("unit"),o.optString("job"),o.optDouble("balance"))) }
        } catch (_: Exception) { stock.clear(); history.clear() }
    }
    private fun text(s:String,size:Float=15f,bold:Boolean=false,color:Int=Color.rgb(28,41,34)): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD); setPadding(dp(2),dp(5),dp(2),dp(5))
    }
    private fun button(s:String, action:()->Unit, primary:Boolean=true): Button = Button(this).apply {
        text=s; isAllCaps=false; textSize=14f
        if(primary){setBackgroundColor(green);setTextColor(Color.WHITE)} else {setBackgroundColor(pale);setTextColor(green)}
        setOnClickListener { action() }
    }
    private fun field(hint:String,value:String="",inputType:Int=android.text.InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
        this.hint=hint; setText(value); textSize=16f; setSingleLine(true); this.inputType=inputType
    }
    private fun addGap(parent:LinearLayout, h:Int=8) { parent.addView(View(this),LinearLayout.LayoutParams(1,dp(h))) }
    private fun showPage() {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,247,244)); setPadding(dp(16),dp(12),dp(16),dp(10)) }
        setContentView(root)
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        content.addView(text("🧰  MAINTENANCE STOCK",23f,true,green))
        content.addView(text("Parts, materials, van stock & job usage",13f,false,Color.DKGRAY))
        addGap(content,8)
        val low=stock.count{it.qty<=it.min}; val value=stock.sumOf{it.qty*it.cost}
        content.addView(text("Items: ${stock.size}     Low stock: $low",16f,true))
        content.addView(text("Estimated stock value: ${money(value)}",14f))
        addGap(content,10)
        val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Stock","Reorder","History","Backup").forEach { p ->
            tabs.addView(button(p,{page=p;showPage()},page==p),LinearLayout.LayoutParams(0,-2,1f))
        }
        content.addView(tabs)
        addGap(content,12)
        when(page) {
            "Stock" -> showStock(content)
            "Reorder" -> showReorder(content)
            "History" -> showHistory(content)
            "Backup" -> showBackup(content)
        }
    }
    private fun money(v:Double)="£"+String.format(Locale.UK,"%.2f",v)
    private fun showStock(c:LinearLayout) {
        c.addView(button("+ Add stock item",{editItem(null)}))
        addGap(c)
        val search=field("Search item, supplier or location",searchText)
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchText=s.toString(); refreshList(c)}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        c.addView(search)
        val check=CheckBox(this).apply { text="Show low stock only"; isChecked=lowOnly; setOnCheckedChangeListener{_,v->lowOnly=v;refreshList(c)} }
        c.addView(check)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; tag="stock_list" }
        c.addView(list)
        fillStockList(list)
    }
    private fun refreshList(parent:LinearLayout) {
        val list=parent.findViewWithTag<LinearLayout>("stock_list") ?: return
        fillStockList(list)
    }
    private fun fillStockList(list:LinearLayout) {
        list.removeAllViews()
        val filtered=stock.filter{("${it.name} ${it.category} ${it.location} ${it.supplier} ${it.notes}").contains(searchText,true) && (!lowOnly || it.qty<=it.min)}
        if(filtered.isEmpty()){list.addView(text("No items found. Add stock or change your search.",15f));return}
        filtered.forEach { x ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(8),dp(12),dp(10)); setBackgroundColor(Color.WHITE) }
            card.addView(text(x.name,18f,true))
            card.addView(text("${x.category} • ${x.location} • ${x.qty} ${x.unit}",14f))
            card.addView(text("Minimum ${x.min} ${x.unit}   |   ${money(x.cost)} each   |   Value ${money(x.qty*x.cost)}",13f,false,if(x.qty<=x.min)Color.rgb(160,80,0) else Color.DKGRAY))
            if(x.supplier.isNotBlank()) card.addView(text("Supplier: ${x.supplier}",13f))
            if(x.notes.isNotBlank()) card.addView(text(x.notes,13f))
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row.addView(button("Use / receive",{movement(x)},true),LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("Edit",{editItem(x)},false),LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("Delete",{AlertDialog.Builder(this).setTitle("Delete ${x.name}?").setMessage("This removes the item from inventory.").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->stock.remove(x);saveData();showPage()}.show()},false),LinearLayout.LayoutParams(0,-2,1f))
            card.addView(row)
            val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);list.addView(card,lp)
        }
    }
    private fun editItem(x:StockItem?) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(4),dp(16),dp(4)) }
        val name=field("Item name",x?.name.orEmpty())
        val qty=field("Quantity",x?.qty?.toString() ?: "0",android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED)
        val min=field("Minimum stock level",x?.min?.toString() ?: "2",android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val cost=field("Unit cost (£)",x?.cost?.toString() ?: "0",android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val supplier=field("Supplier",x?.supplier.orEmpty())
        val notes=field("Part number / notes",x?.notes.orEmpty())
        val cat=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,cats); setSelection(cats.indexOf(x?.category).coerceAtLeast(0)) }
        val loc=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,locations); setSelection(locations.indexOf(x?.location).coerceAtLeast(0)) }
        val unit=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,units); setSelection(units.indexOf(x?.unit).coerceAtLeast(0)) }
        listOf("Item name", "Category").forEachIndexed{ i,s->box.addView(text(s,13f,true)); if(i==0)box.addView(name) else box.addView(cat)}
        box.addView(text("Storage location",13f,true));box.addView(loc)
        box.addView(text("Quantity",13f,true));box.addView(qty)
        box.addView(text("Unit",13f,true));box.addView(unit)
        box.addView(text("Minimum stock",13f,true));box.addView(min)
        box.addView(text("Unit cost (£)",13f,true));box.addView(cost)
        box.addView(text("Supplier",13f,true));box.addView(supplier)
        box.addView(text("Notes / part number",13f,true));box.addView(notes)
        val scroll=ScrollView(this);scroll.addView(box)
        AlertDialog.Builder(this).setTitle(if(x==null)"Add stock item" else "Edit stock item").setView(scroll)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val n=qty.text.toString().toDoubleOrNull();val mn=min.text.toString().toDoubleOrNull();val co=cost.text.toString().toDoubleOrNull()
                    if(name.text.toString().isBlank()||n==null||mn==null||co==null||n<0||mn<0||co<0){Toast.makeText(this,"Enter a name and valid non-negative numbers.",Toast.LENGTH_LONG).show();return@setOnClickListener}
                    val item=StockItem(x?.id ?: "MS-"+UUID.randomUUID().toString().take(8).uppercase(),name.text.toString().trim(),cat.selectedItem.toString(),n,unit.selectedItem.toString(),mn,co,loc.selectedItem.toString(),supplier.text.toString().trim(),notes.text.toString().trim())
                    if(x==null)stock.add(0,item) else {val i=stock.indexOfFirst{it.id==x.id};if(i>=0)stock[i]=item}
                    saveData();d.dismiss();showPage()
                } }
            }.show()
    }
    private fun movement(x:StockItem) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(4)) }
        val type=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Used on job","Received","Stock correction / write-off")) }
        val qty=field("Quantity", "1",android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val job=field("Job / property reference")
        box.addView(text("${x.name} — balance ${x.qty} ${x.unit}",14f,true));box.addView(type);box.addView(qty);box.addView(job)
        AlertDialog.Builder(this).setTitle("Stock movement").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Confirm",null).create().also{d->
            d.setOnShowListener{d.getButton(-1).setOnClickListener{
                val n=qty.text.toString().toDoubleOrNull();val t=type.selectedItem.toString()
                if(n==null||n<=0){Toast.makeText(this,"Enter a quantity above zero.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
                if(t!="Received"&&n>x.qty){Toast.makeText(this,"Not enough stock available.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
                x.qty=if(t=="Received")x.qty+n else x.qty-n
                history.add(0,Movement(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.UK).format(Date()),x.name,t,n,x.unit,job.text.toString().trim(),x.qty))
                saveData();d.dismiss();showPage()
            }}
        }.show()
    }
    private fun showReorder(c:LinearLayout) {
        c.addView(text("Items at or below minimum stock",19f,true))
        val items=stock.filter{it.qty<=it.min}
        if(items.isEmpty())c.addView(text("All stock levels look good."))
        items.forEach{x->c.addView(text("${x.name}\nCurrent: ${x.qty} ${x.unit} • Minimum: ${x.min}\nSuggested order: ${maxOf(0.0,x.min*2-x.qty)} ${x.unit}\nSupplier: ${x.supplier.ifBlank{"Not specified"}}",15f,true));c.addView(button("Edit item",{editItem(x)},false));addGap(c)}
        c.addView(button("Export reorder list",{exportCsv("maintenance-reorder.csv","Item,Category,Current,Unit,Minimum,Suggested order,Supplier,Location\n"+items.joinToString("\n"){csv(listOf(it.name,it.category,it.qty,it.unit,it.min,maxOf(0.0,it.min*2-it.qty),it.supplier,it.location))})}))
    }
    private fun showHistory(c:LinearLayout) {
        c.addView(text("Stock movement history",19f,true))
        if(history.isEmpty())c.addView(text("No movements recorded yet."))
        history.forEach{x->c.addView(text("${x.date} • ${x.item}\n${x.type}: ${x.qty} ${x.unit}${if(x.job.isNotBlank())" • Job: ${x.job}" else ""}\nBalance: ${x.balance} ${x.unit}",15f));addGap(c)}
        c.addView(button("Export movement history",{exportHistory()}))
    }
    private fun showBackup(c:LinearLayout) {
        c.addView(text("Backup & export",19f,true))
        c.addView(text("Export stock and movement history as CSV files. Android will ask where to save each file."))
        addGap(c)
        c.addView(button("Export stock CSV",{exportStock()}))
        c.addView(button("Export movement history CSV",{exportHistory()}))
        c.addView(button("Export reorder list CSV",{exportReorder()}))
        addGap(c,12)
        c.addView(text("Inventory data is stored on this phone. Export backups regularly.",14f,false,Color.DKGRAY))
        c.addView(button("Clear all inventory",{AlertDialog.Builder(this).setTitle("Clear all data?").setMessage("This permanently deletes all items and movement history on this phone.").setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->stock.clear();history.clear();saveData();showPage()}.show()},false))
    }
    private fun csv(values:List<Any?>)=values.joinToString(","){ "\""+(it?.toString() ?: "").replace("\"","\"\"")+"\"" }
    private fun exportCsv(name:String,content:String) {
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(Intent.EXTRA_TITLE,name)}
        pendingExport=content
        try{startActivityForResult(intent,99)}catch(_:Exception){Toast.makeText(this,"Could not open file picker.",Toast.LENGTH_LONG).show()}
    }
    private var pendingExport=""
    @Deprecated("Deprecated in Android SDK but supported")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {super.onActivityResult(requestCode,resultCode,data);if(requestCode==99&&resultCode==RESULT_OK&&data?.data!=null){try{contentResolver.openOutputStream(data.data!!)?.use{it.write(("\uFEFF"+pendingExport).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Export saved.",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"Export failed: ${e.message}",Toast.LENGTH_LONG).show()}}}
    private fun exportStock(){exportCsv("maintenance-stock.csv","ID,Item,Category,Quantity,Unit,Minimum,Unit cost,Stock value,Location,Supplier,Notes\n"+stock.joinToString("\n"){csv(listOf(it.id,it.name,it.category,it.qty,it.unit,it.min,it.cost,it.qty*it.cost,it.location,it.supplier,it.notes))})}
    private fun exportHistory(){exportCsv("maintenance-movements.csv","Date,Item,Movement,Quantity,Unit,Job,Remaining balance\n"+history.joinToString("\n"){csv(listOf(it.date,it.item,it.type,it.qty,it.unit,it.job,it.balance))})}
    private fun exportReorder(){val a=stock.filter{it.qty<=it.min};exportCsv("maintenance-reorder.csv","Item,Category,Current,Unit,Minimum,Suggested order,Supplier,Location\n"+a.joinToString("\n"){csv(listOf(it.name,it.category,it.qty,it.unit,it.min,maxOf(0.0,it.min*2-it.qty),it.supplier,it.location))})}
}
